/******************************************************************************
 * Copyright (c) 2015 Institut fuer Informationsverarbeitung (TNT)            *
 * Contact: Jan Voges <jvoges@tnt.uni-hannover.de>                            *
 *                                                                            *
 * This file is part of tsc.                                                  *
 ******************************************************************************/

#ifndef TSC_VERSION_H
#define TSC_VERSION_H

#define VERSION "01.00" /* this must be exactly five (5) characters */

#endif /* TSC_VERSION_H */

